CREATE VIEW developers_view_with_check_option AS
  SELECT
    `developers`.`people`.`name`      AS `NAME`,
    `developers`.`people`.`specialty` AS `SPECIALTY`
  FROM `developers`.`people`
  WHERE (`developers`.`people`.`specialty` IS NOT NULL);
