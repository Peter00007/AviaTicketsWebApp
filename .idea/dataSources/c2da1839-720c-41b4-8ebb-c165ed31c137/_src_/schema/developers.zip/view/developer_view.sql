CREATE VIEW developers.developer_view AS
  SELECT
    `developers`.`people`.`name`      AS `name`,
    `developers`.`people`.`specialty` AS `specialty`,
    `developers`.`people`.`salary`    AS `salary`
  FROM `developers`.`people`;
